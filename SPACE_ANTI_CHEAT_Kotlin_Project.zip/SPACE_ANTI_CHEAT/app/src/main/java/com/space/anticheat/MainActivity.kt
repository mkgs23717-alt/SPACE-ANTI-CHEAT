package com.space.anticheat

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 14, 27)
    private val panel = Color.rgb(17, 29, 49)
    private val blue = Color.rgb(76, 169, 255)
    private val white = Color.rgb(235, 243, 255)
    private val muted = Color.rgb(150, 169, 197)
    private val green = Color.rgb(75, 213, 155)
    private val amber = Color.rgb(255, 197, 92)

    private lateinit var root: LinearLayout
    private lateinit var deviceValues: TextView
    private lateinit var matchValues: TextView
    private lateinit var historyValues: TextView
    private lateinit var statusText: TextView
    private var lastCpuTime = Process.getElapsedCpuTime()
    private var lastWallTime = SystemClock.elapsedRealtime()
    private val handler = Handler(Looper.getMainLooper())

    private val refreshTask = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                updateDevicePanel()
                handler.postDelayed(this, 2000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        updateDevicePanel()
        updateHistory()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refreshTask)
        handler.post(refreshTask)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshTask)
        super.onPause()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        scroll.addView(root)
        setContentView(scroll)

        text("SPACE ANTI-CHEAT", 25f, blue, true)
        text("DEVICE MONITORING  •  MATCH REVIEW  •  REPORTS", 11f, muted, true)
        text("SAC 1.0  |  Android ${Build.VERSION.RELEASE}", 12f, muted)
        section("CIHAZ DURUMU")
        deviceValues = text("Cihaz bilgileri okunuyor...", 14f, white)
        section("MAÇ KAYDI ANALİZİ")
        matchValues = text(
            "Henüz maç kaydı içe aktarılmadı.\n\nCSV başlıkları:\nplayer,kills,deaths,headshots,shots,hits,aim_snap_count,avg_reaction_ms,match_id",
            13f, muted
        )
        button("MAÇ CSV DOSYASI İÇE AKTAR") { chooseCsv() }
        button("ANALİZ RAPORUNU JSON OLARAK DIŞA AKTAR") { exportReport() }
        statusText = text("Hazır. Analizler cihaz üzerinde yerel olarak yapılır.", 12f, green)
        section("ANALİZ GEÇMİŞİ")
        historyValues = text("Henüz kayıt yok.", 13f, muted)
        section("ÖNEMLİ SINIRLAR")
        text(
            "• Bu uygulama Standoff 2 belleğini veya rakip cihazlarını izlemez.\n" +
            "• FPS, başka uygulamaların özel oyun telemetrisi olmadan kesin ölçülemez.\n" +
            "• CPU yüzdesi bu uygulamanın kendi işlem yükünü gösterir.\n" +
            "• Şüphe göstergeleri hile kanıtı değildir; otomatik ban verilmez.\n" +
            "• Maç kayıtları yalnızca seçtiğin CSV dosyasından okunur.",
            12f, muted
        )
    }

    private fun updateDevicePanel() {
        if (!::deviceValues.isInitialized) return
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val totalRam = mem.totalMem / (1024.0 * 1024.0 * 1024.0)
        val availRam = mem.availMem / (1024.0 * 1024.0 * 1024.0)
        val usedRam = (totalRam - availRam).coerceAtLeast(0.0)

        val nowCpu = Process.getElapsedCpuTime()
        val nowWall = SystemClock.elapsedRealtime()
        val cpuDelta = (nowCpu - lastCpuTime).coerceAtLeast(0)
        val wallDelta = (nowWall - lastWallTime).coerceAtLeast(1)
        val appCpu = (cpuDelta.toDouble() / wallDelta.toDouble() * 100.0)
            .coerceIn(0.0, 100.0 * Runtime.getRuntime().availableProcessors())
        lastCpuTime = nowCpu
        lastWallTime = nowWall

        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else -1
        val tempTenths = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val temp = if (tempTenths >= 0) String.format(Locale.US, "%.1f°C", tempTenths / 10f) else "Desteklenmiyor"
        val charging = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chargingText = if (charging == BatteryManager.BATTERY_STATUS_CHARGING ||
            charging == BatteryManager.BATTERY_STATUS_FULL) "Şarjda" else "Şarjda değil"

        @Suppress("DEPRECATION")
        val screenDisplay = if (Build.VERSION.SDK_INT >= 30) this.display else windowManager.defaultDisplay
        val hz = screenDisplay?.refreshRate ?: 0f

        val appMem = Debug.MemoryInfo()
        Debug.getMemoryInfo(appMem)
        val appPssMb = appMem.totalPss / 1024.0

        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Hafif"
                PowerManager.THERMAL_STATUS_MODERATE -> "Orta"
                PowerManager.THERMAL_STATUS_SEVERE -> "Yüksek"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Kritik"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Acil"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Kapanma seviyesi"
                else -> "Bilinmiyor"
            }
        } else "Android sürümünde desteklenmiyor"

        deviceValues.text =
            "Model: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "İşlemci çekirdeği: ${Runtime.getRuntime().availableProcessors()}\n" +
            "RAM kullanımı (sistem): ${fmt(usedRam)} / ${fmt(totalRam)} GB\n" +
            "Boş RAM: ${fmt(availRam)} GB\n" +
            "SPACE uygulaması RAM: ${fmt(appPssMb / 1024.0)} GB (PSS)\n" +
            "SPACE uygulaması CPU: ${String.format(Locale.US, "%.1f", appCpu)}%\n" +
            "Ekran yenileme: ${String.format(Locale.US, "%.1f", hz)} Hz\n" +
            "Pil: ${if (batteryPct >= 0) "$batteryPct%" else "Bilinmiyor"} • $chargingText\n" +
            "Pil sıcaklığı: $temp\n" +
            "Android termal durumu: $thermal\n" +
            "Güncelleme: 2 saniyede bir"
    }

    private fun chooseCsv() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Using activity result for broad compatibility with mobile IDE templates")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            importCsv(uri)
        } else if (requestCode == 1002 && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            writeReport(uri)
        }
    }

    private data class MatchRow(
        val player: String, val kills: Int, val deaths: Int, val headshots: Int,
        val shots: Int, val hits: Int, val snaps: Int, val reactionMs: Double, val matchId: String,
        val reviewScore: Int, val reasons: List<String>
    )

    private var latestRows: List<MatchRow> = emptyList()

    private fun importCsv(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: error("Dosya açılamadı")
            val lines = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readLines() }
                .filter { it.isNotBlank() }
            if (lines.size < 2) error("CSV içinde başlık ve en az bir veri satırı olmalı.")
            val headers = parseCsvLine(lines.first().removePrefix("\uFEFF")).map { it.trim().lowercase(Locale.ROOT) }
            val required = listOf("player", "kills", "deaths", "headshots", "shots", "hits")
            val missing = required.filter { it !in headers }
            if (missing.isNotEmpty()) error("Eksik CSV sütunları: ${missing.joinToString()}")
            val parsed = mutableListOf<MatchRow>()
            lines.drop(1).forEachIndexed { index, line ->
                val cols = parseCsvLine(line)
                fun value(key: String, default: String = ""): String {
                    val i = headers.indexOf(key)
                    return if (i >= 0 && i < cols.size) cols[i].trim() else default
                }
                fun number(key: String, default: Int = 0): Int =
                    value(key).toIntOrNull() ?: default
                val player = value("player").ifBlank { "Bilinmeyen oyuncu" }
                val k = number("kills")
                val d = number("deaths")
                val hs = number("headshots")
                val shots = number("shots")
                val hits = number("hits")
                val snaps = number("aim_snap_count")
                val reaction = value("avg_reaction_ms").toDoubleOrNull() ?: -1.0
                val matchId = value("match_id", "Satır ${index + 2}")
                if (listOf(k, d, hs, shots, hits, snaps).any { it < 0 } ||
                    hs > k || hits > shots || player.length > 100) {
                    throw IllegalArgumentException("Satır ${index + 2}: veri aralığı geçersiz.")
                }
                val reasons = mutableListOf<String>()
                var score = 0
                val accuracy = if (shots > 0) hits * 100.0 / shots else 0.0
                val hsRate = if (k > 0) hs * 100.0 / k else 0.0
                // These are conservative review prompts, not validated cheat detection thresholds.
                if (shots >= 40 && accuracy >= 80.0) {
                    score += 15; reasons.add("Yüksek isabet oranı; maç bağlamı incelensin")
                }
                if (k >= 15 && hsRate >= 80.0) {
                    score += 15; reasons.add("Yüksek kafa vuruşu oranı; örneklem küçük olabilir")
                }
                if (snaps >= 20 && k >= 10) {
                    score += 10; reasons.add("Aim snap sayısı yüksek; ham kayıt gerekli")
                }
                if (reaction >= 0 && reaction < 120 && k >= 10) {
                    score += 10; reasons.add("Çok düşük ortalama tepki süresi; ölçüm yöntemi doğrulansın")
                }
                parsed.add(MatchRow(player, k, d, hs, shots, hits, snaps, reaction, matchId,
                    score.coerceAtMost(100), reasons))
            }
            if (parsed.isEmpty()) error("Analiz edilecek satır bulunamadı.")
            latestRows = parsed
            val avgScore = parsed.map { it.reviewScore }.average().roundToInt()
            val flagged = parsed.count { it.reviewScore >= 25 }
            matchValues.text = buildString {
                append("İçe aktarılan maç satırı: ${parsed.size}\n")
                append("Manuel inceleme önerilen satır: $flagged\n")
                append("Ortalama inceleme göstergesi: $avgScore/100\n\n")
                parsed.take(20).forEach {
                    append("${it.player} • ${it.matchId}\n")
                    append("K/D: ${it.kills}/${it.deaths} • HS: ${it.headshots} • ")
                    append("İnceleme: ${it.reviewScore}/100\n")
                    append(if (it.reasons.isEmpty()) "Belirgin gösterge yok.\n\n"
                    else it.reasons.joinToString("; ") + "\n\n")
                }
                if (parsed.size > 20) append("İlk 20 satır gösteriliyor. Rapor dışa aktarımında tüm satırlar bulunur.")
            }
            statusText.text = "CSV analiz edildi. Sonuçlar yalnızca inceleme göstergesidir."
            statusText.setTextColor(amber)
            saveHistory(parsed)
        } catch (e: Exception) {
            statusText.text = "CSV hatası: ${e.message ?: "Dosya okunamadı"}"
            statusText.setTextColor(Color.RED)
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    cell.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> {
                    out.add(cell.toString()); cell.setLength(0)
                }
                else -> cell.append(c)
            }
            i++
        }
        out.add(cell.toString())
        return out
    }

    private fun saveHistory(rows: List<MatchRow>) {
        val arr = JSONArray()
        val old = getPreferences(MODE_PRIVATE).getString("history", "[]")
        val previous = JSONArray(old)
        for (i in 0 until minOf(previous.length(), 25)) arr.put(previous.getJSONObject(i))
        rows.take(10).forEach { row ->
            arr.put(JSONObject().apply {
                put("player", row.player); put("match", row.matchId)
                put("score", row.reviewScore); put("time", System.currentTimeMillis())
            })
        }
        getPreferences(MODE_PRIVATE).edit().putString("history", arr.toString()).apply()
        updateHistory()
    }

    private fun updateHistory() {
        if (!::historyValues.isInitialized) return
        val arr = JSONArray(getPreferences(MODE_PRIVATE).getString("history", "[]"))
        if (arr.length() == 0) {
            historyValues.text = "Henüz analiz kaydı yok."
            return
        }
        historyValues.text = buildString {
            for (i in 0 until minOf(arr.length(), 20)) {
                val o = arr.getJSONObject(i)
                append("${o.optString("player")} • ${o.optString("match")} • ")
                append("${o.optInt("score")}/100 inceleme göstergesi\n")
            }
        }
    }

    private fun exportReport() {
        if (latestRows.isEmpty()) {
            statusText.text = "Önce bir CSV maç kaydı içe aktar."
            statusText.setTextColor(amber)
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "space_anti_cheat_report.json")
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 1002)
    }

    private fun writeReport(uri: Uri) {
        try {
            val report = JSONObject().apply {
                put("application", "SPACE ANTI-CHEAT")
                put("version", "1.0")
                put("created_at_epoch_ms", System.currentTimeMillis())
                put("disclaimer", "Review indicators are not proof of cheating. Human review required.")
                put("device", JSONObject().apply {
                    put("manufacturer", Build.MANUFACTURER)
                    put("model", Build.MODEL)
                    put("android", Build.VERSION.RELEASE)
                })
                put("matches", JSONArray().apply {
                    latestRows.forEach { row ->
                        put(JSONObject().apply {
                            put("player", row.player); put("match_id", row.matchId)
                            put("kills", row.kills); put("deaths", row.deaths)
                            put("headshots", row.headshots); put("shots", row.shots)
                            put("hits", row.hits); put("aim_snap_count", row.snaps)
                            put("avg_reaction_ms", row.reactionMs)
                            put("review_indicator_score", row.reviewScore)
                            put("reasons", JSONArray(row.reasons))
                        })
                    }
                })
            }
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(report.toString(2))
            } ?: error("Dosyaya yazılamadı")
            statusText.text = "JSON raporu kaydedildi. Yetkiliye iletmeden önce verileri doğrula."
            statusText.setTextColor(green)
        } catch (e: Exception) {
            statusText.text = "Rapor hatası: ${e.message}"
            statusText.setTextColor(Color.RED)
        }
    }

    private fun section(title: String) {
        val t = text(title, 14f, blue, true)
        t.setPadding(0, dp(22), 0, dp(8))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
            rootOrAdd(this)
        }
    }

    private fun rootOrAdd(view: View) {
        if (::root.isInitialized) root.addView(view, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(24, 105, 190))
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })
    }

    private fun fmt(value: Double): String = String.format(Locale.US, "%.2f", value)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
