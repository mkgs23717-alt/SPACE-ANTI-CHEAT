# SPACE ANTI-CHEAT 1.0 — Android/Kotlin

Realme C55 / Android 15 için hazırlanmış, rootsuz ve yerel çalışan Android proje başlangıcı.

## Özellikler
- Cihaz modeli ve Android sürümü
- Sistem RAM kullanımı ve boş RAM
- Uygulamanın kendi PSS bellek kullanımı
- Uygulamanın kendi CPU zamanı üzerinden yaklaşık CPU yükü
- Ekran yenileme hızı
- Pil yüzdesi, şarj durumu ve pil sıcaklığı
- Android termal durum API'si (destekleniyorsa)
- CSV maç kaydı içe aktarma
- Şeffaf inceleme göstergeleri
- Yerel analiz geçmişi
- JSON raporu dışa aktarma

## Gerçekçi sınırlar
Android 10 ve üzerindeki kısıtlamalar nedeniyle normal bir uygulama diğer uygulamaların özel süreç belleğini okuyamaz. Bu nedenle CPU göstergesi SPACE ANTI-CHEAT uygulamasının kendi CPU yüküdür. Ekran Hz değeri oyunun FPS değeri değildir. Standoff 2'nin korumalı oyun belleği, rakiplerin gizli aim hareketleri veya sunucu anti-cheat verileri okunmaz.

CSV analizi yalnızca içe aktarılan sütunları değerlendirir. Kullanılan eşikler doğrulanmış hile sınıflandırıcısı değildir; yalnızca insan incelemesi için ön işarettir. Otomatik ban işlevi yoktur.

## CSV biçimi
Zorunlu başlıklar:
`player,kills,deaths,headshots,shots,hits`

İsteğe bağlı:
`aim_snap_count,avg_reaction_ms,match_id`

Örnek `sample_matches.csv` dosyasındadır. Her satır bir oyuncunun tek maç özetidir. Ham zaman damgalı aim verisi değildir.

## Telefonda derleme
Önerilen mobil IDE: Code on the Go (CoGo). AndroidIDE 2024'te arşivlendiği için yeni kurulumda onu önermiyoruz. CoGo, Android telefonlarda Gradle tabanlı Kotlin/Java Android projeleri derlemeyi hedefleyen devam projesidir.

1. CoGo'yu resmi App Dev for All sayfasından kur: https://appdevforall.org/code-on-the-go/
2. Bu ZIP'i telefona indirip çıkart.
3. CoGo'da Open Existing Project seçip `SPACE_ANTI_CHEAT` klasörünü aç.
4. Gradle senkronizasyonunun tamamlanmasını bekle. İlk derlemede internet gerekebilir.
5. Run/Build APK seçeneğiyle debug APK oluştur.
6. APK kurulumunu Android'in istediği normal uygulama izniyle onayla.

## Teknik yapı
- Android Gradle Plugin 8.7.3
- Kotlin Android 2.0.21
- compileSdk 35
- minSdk 26
- JDK 17

Bu kaynak paketi APK değildir. CoGo ile cihazında derlenmesi gerekir.
